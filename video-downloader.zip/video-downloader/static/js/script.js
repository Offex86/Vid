document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const videoUrlInput = document.getElementById('videoUrl');
    const fetchInfoBtn = document.getElementById('fetchInfoBtn');
    const videoInfoSection = document.getElementById('videoInfo');
    const videoThumbnail = document.getElementById('videoThumbnail');
    const videoTitle = document.getElementById('videoTitle');
    const videoDuration = document.getElementById('videoDuration');
    const videoFormatsContainer = document.getElementById('videoFormats');
    const audioFormatsContainer = document.getElementById('audioFormats');
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const downloadProgress = document.getElementById('downloadProgress');
    const progressFill = document.querySelector('.progress-fill');
    const progressText = document.querySelector('.progress-text');
    const downloadLink = document.getElementById('downloadLink');
    const ttsText = document.getElementById('ttsText');
    const generateTtsBtn = document.getElementById('generateTtsBtn');
    
    let currentVideoInfo = null;
    let selectedFormat = null;
    
    // Tab switching
    tabBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            
            // Update active tab button
            tabBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            
            // Show corresponding tab content
            tabContents.forEach(content => content.classList.add('hidden'));
            document.getElementById(`${tabId}Tab`).classList.remove('hidden');
        });
    });
    
    // Fetch video info
    fetchInfoBtn.addEventListener('click', fetchVideoInfo);
    videoUrlInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') fetchVideoInfo();
    });
    
    // Text-to-speech generation
    generateTtsBtn.addEventListener('click', generateTTS);
    
    async function fetchVideoInfo() {
        const url = videoUrlInput.value.trim();
        
        if (!url) {
            alert('Please enter a video URL');
            return;
        }
        
        try {
            fetchInfoBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Analyzing...';
            fetchInfoBtn.disabled = true;
            
            const response = await fetch('/api/get_info', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `url=${encodeURIComponent(url)}`
            });
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            currentVideoInfo = data;
            displayVideoInfo(data);
            
            videoInfoSection.classList.remove('hidden');
            downloadProgress.classList.add('hidden');
            
        } catch (error) {
            console.error('Error:', error);
            alert(`Failed to fetch video info: ${error.message}`);
        } finally {
            fetchInfoBtn.innerHTML = '<i class="fas fa-search"></i> Analyze';
            fetchInfoBtn.disabled = false;
        }
    }
    
    function displayVideoInfo(info) {
        videoThumbnail.src = info.thumbnail || 'https://via.placeholder.com/160x90';
        videoTitle.textContent = info.title || 'Untitled';
        
        // Format duration
        if (info.duration) {
            const hours = Math.floor(info.duration / 3600);
            const minutes = Math.floor((info.duration % 3600) / 60);
            const seconds = Math.floor(info.duration % 60);
            
            let durationStr = '';
            if (hours > 0) durationStr += `${hours}:`;
            durationStr += `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            videoDuration.innerHTML = `<i class="fas fa-clock"></i> ${durationStr}`;
        } else {
            videoDuration.innerHTML = '<i class="fas fa-clock"></i> Unknown';
        }
        
        // Display video formats
        videoFormatsContainer.innerHTML = '';
        if (info.formats && info.formats.length > 0) {
            info.formats.forEach(format => {
                const formatCard = createFormatCard(format, 'video');
                videoFormatsContainer.appendChild(formatCard);
            });
        } else {
            videoFormatsContainer.innerHTML = '<p>No video formats available</p>';
        }
        
        // Display audio formats
        audioFormatsContainer.innerHTML = '';
        if (info.audio_formats && info.audio_formats.length > 0) {
            info.audio_formats.forEach(format => {
                const formatCard = createFormatCard(format, 'audio');
                audioFormatsContainer.appendChild(formatCard);
            });
        } else {
            audioFormatsContainer.innerHTML = '<p>No audio formats available</p>';
        }
    }
    
    function createFormatCard(format, type) {
        const card = document.createElement('div');
        card.className = 'option-card';
        card.dataset.formatId = format.format_id;
        card.dataset.ext = format.ext;
        
        if (type === 'video') {
            card.innerHTML = `
                <div class="format-name">${format.quality || format.resolution || 'Unknown'}</div>
                <div class="format-details">${format.ext.toUpperCase()} • ${format.fps || '?'}fps</div>
            `;
        } else {
            // Audio format
            card.innerHTML = `
                <div class="format-name">${format.abr ? `${format.abr}kbps` : 'Unknown'}</div>
                <div class="format-details">${format.ext.toUpperCase()} • ${format.audio_channels}ch</div>
            `;
        }
        
        card.addEventListener('click', function() {
            // Remove selected class from all cards
            document.querySelectorAll('.option-card').forEach(c => c.classList.remove('selected'));
            
            // Add selected class to clicked card
            this.classList.add('selected');
            
            selectedFormat = {
                format_id: this.dataset.formatId,
                ext: this.dataset.ext,
                type: type
            };
            
            // Show download progress section
            downloadProgress.classList.remove('hidden');
            downloadLink.classList.add('hidden');
            progressFill.style.width = '0%';
            progressText.textContent = 'Ready to download';
            
            // Auto-start download if preferred
            startDownload();
        });
        
        return card;
    }
    
    async function startDownload() {
        if (!currentVideoInfo || !selectedFormat) return;
        
        try {
            progressText.textContent = 'Preparing download...';
            progressFill.style.width = '30%';
            
            let outputFormat = selectedFormat.ext;
            if (selectedFormat.type === 'video' && !['mp4', 'webm', 'mkv'].includes(outputFormat)) {
                outputFormat = 'mp4';
            } else if (selectedFormat.type === 'audio' && !['mp3', 'm4a', 'ogg'].includes(outputFormat)) {
                outputFormat = 'mp3';
            }
            
            const response = await fetch('/api/download', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `url=${encodeURIComponent(currentVideoInfo.url)}&format_id=${encodeURIComponent(selectedFormat.format_id)}&output_format=${outputFormat}`
            });
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            progressFill.style.width = '100%';
            progressText.textContent = 'Download ready!';
            
            // Show download link
            downloadLink.href = data.download_url;
            downloadLink.textContent = `Download ${data.filename}`;
            downloadLink.classList.remove('hidden');
            
        } catch (error) {
            console.error('Download error:', error);
            progressText.textContent = `Error: ${error.message}`;
            progressFill.style.width = '0%';
        }
    }
    
    async function generateTTS() {
        const text = ttsText.value.trim();
        
        if (!text) {
            alert('Please enter some text to convert to speech');
            return;
        }
        
        try {
            generateTtsBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Generating...';
            generateTtsBtn.disabled = true;
            
            const response = await fetch('/api/text_to_speech', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `text=${encodeURIComponent(text)}`
            });
            
            const data = await response.json();
            
            if (data.error) {
                throw new Error(data.error);
            }
            
            // Show download link
            downloadProgress.classList.remove('hidden');
            progressFill.style.width = '100%';
            progressText.textContent = 'Speech generated!';
            
            downloadLink.href = data.download_url;
            downloadLink.textContent = `Download ${data.filename}`;
            downloadLink.classList.remove('hidden');
            
        } catch (error) {
            console.error('TTS error:', error);
            alert(`Failed to generate speech: ${error.message}`);
        } finally {
            generateTtsBtn.innerHTML = '<i class="fas fa-volume-up"></i> Generate Speech';
            generateTtsBtn.disabled = false;
        }
    }
});