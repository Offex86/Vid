import os
import re
import subprocess
from flask import Flask, render_template, request, jsonify, send_file
from werkzeug.utils import secure_filename
from uuid import uuid4
import yt_dlp

app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB limit
app.config['DOWNLOAD_FOLDER'] = 'downloads'
app.config['TEMP_FOLDER'] = 'temp'

# Ensure download directories exist
os.makedirs(app.config['DOWNLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['TEMP_FOLDER'], exist_ok=True)

def sanitize_filename(filename):
    """Sanitize the filename to remove unsafe characters"""
    filename = secure_filename(filename)
    filename = re.sub(r'[^\w\-_. ]', '', filename)
    return filename

def get_video_info(url):
    """Get available formats for a video"""
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'extract_flat': True,
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            if not info:
                return None
                
            formats = []
            audio_formats = []
            
            if 'formats' in info:
                for f in info['formats']:
                    if f.get('vcodec') != 'none':  # Video formats
                        formats.append({
                            'format_id': f['format_id'],
                            'ext': f['ext'],
                            'resolution': f.get('resolution', 'unknown'),
                            'height': f.get('height', 0),
                            'width': f.get('width', 0),
                            'fps': f.get('fps', 0),
                            'quality': f'{f.get("height", "?")}p{f.get("fps", "")}',
                            'note': f.get('format_note', ''),
                        })
                    elif f.get('acodec') != 'none':  # Audio formats
                        audio_formats.append({
                            'format_id': f['format_id'],
                            'ext': f['ext'],
                            'abr': f.get('abr', 0),
                            'audio_channels': f.get('audio_channels', 2),
                        })
            
            # Sort formats by resolution
            formats.sort(key=lambda x: x.get('height', 0), reverse=True)
            audio_formats.sort(key=lambda x: x.get('abr', 0), reverse=True)
            
            return {
                'title': info.get('title', 'Untitled'),
                'thumbnail': info.get('thumbnail', ''),
                'duration': info.get('duration', 0),
                'formats': formats,
                'audio_formats': audio_formats,
                'url': url
            }
    except Exception as e:
        print(f"Error getting video info: {str(e)}")
        return None

def download_video(url, format_id, output_format):
    """Download video in specified format"""
    unique_id = str(uuid4())
    output_template = os.path.join(
        app.config['DOWNLOAD_FOLDER'],
        f'{unique_id}.%(ext)s'
    )
    
    ydl_opts = {
        'format': format_id,
        'outtmpl': output_template,
        'quiet': True,
        'no_warnings': True,
    }
    
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            
            if not info:
                return None
                
            downloaded_file = output_template.replace('%(ext)s', info['ext'])
            
            # Convert to desired output format if needed
            if output_format != info['ext']:
                new_filename = downloaded_file.replace(f'.{info["ext"]}', f'.{output_format}')
                cmd = [
                    'ffmpeg',
                    '-i', downloaded_file,
                    '-c', 'copy',
                    new_filename
                ]
                subprocess.run(cmd, check=True)
                os.remove(downloaded_file)
                downloaded_file = new_filename
            
            return downloaded_file
    except Exception as e:
        print(f"Error downloading video: {str(e)}")
        return None

@app.route('/', methods=['GET'])
def index():
    return render_template('index.html')

@app.route('/api/get_info', methods=['POST'])
def api_get_info():
    url = request.form.get('url')
    if not url:
        return jsonify({'error': 'URL is required'}), 400
    
    info = get_video_info(url)
    if not info:
        return jsonify({'error': 'Could not fetch video information'}), 400
    
    return jsonify(info)

@app.route('/api/download', methods=['POST'])
def api_download():
    url = request.form.get('url')
    format_id = request.form.get('format_id')
    output_format = request.form.get('output_format', 'mp4')
    
    if not url or not format_id:
        return jsonify({'error': 'Missing parameters'}), 400
    
    downloaded_file = download_video(url, format_id, output_format)
    if not downloaded_file:
        return jsonify({'error': 'Download failed'}), 500
    
    filename = os.path.basename(downloaded_file)
    return jsonify({
        'download_url': f'/download/{filename}',
        'filename': filename
    })

@app.route('/download/<filename>', methods=['GET'])
def download_file(filename):
    file_path = os.path.join(app.config['DOWNLOAD_FOLDER'], filename)
    if not os.path.exists(file_path):
        return "File not found", 404
    
    return send_file(
        file_path,
        as_attachment=True,
        download_name=filename
    )

@app.route('/api/text_to_speech', methods=['POST'])
def text_to_speech():
    text = request.form.get('text')
    if not text:
        return jsonify({'error': 'Text is required'}), 400
    
    unique_id = str(uuid4())
    output_file = os.path.join(app.config['TEMP_FOLDER'], f'{unique_id}.mp3')
    
    try:
        # Using gTTS for text-to-speech
        from gtts import gTTS
        tts = gTTS(text=text, lang='en', slow=False)
        tts.save(output_file)
        
        return jsonify({
            'download_url': f'/download_tts/{unique_id}.mp3',
            'filename': f'{unique_id}.mp3'
        })
    except Exception as e:
        print(f"Error in TTS: {str(e)}")
        return jsonify({'error': 'Text-to-speech conversion failed'}), 500

@app.route('/download_tts/<filename>', methods=['GET'])
def download_tts(filename):
    file_path = os.path.join(app.config['TEMP_FOLDER'], filename)
    if not os.path.exists(file_path):
        return "File not found", 404
    
    return send_file(
        file_path,
        as_attachment=True,
        download_name=f"speech_{filename}"
    )

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)